from firebase import firebase
firebase=firebase.FirebaseApplication('https://studentattendancesystem-a6fbd.firebaseio.com/')
import time
from datetime import datetime

t=str("14113560217239")+'/'+str("usn")
usn1=firebase.get('/StudentQueue/',t)
print(usn1)

now=time.ctime()
print(now)
temp=now.split(' ')
print(temp)
day=temp[0]
month=temp[1]
date=temp[3]
year=temp[5]
time=temp[4]

if month=="Jan":
    m=1
elif month=="Feb":
    m=2
elif month=="Mar":
    m=3
elif month=="Apr":
    m=4
elif month=="May":
    m=5
elif month=="Jun":
    m=6
elif month=="Jul":
    m=7
elif month=="Aug":
    m=8
elif month=="Sep":
    m=9
elif month=="Oct":
    m=10
elif month=="Nov":
    m=11
elif month=="Dec":
    m=12


y=usn1[3:5]
b=usn1[5:7]
code=usn1[7:]

cur_year=int(year)-2000-int(y)
print(cur_year)

if cur_year==0 and m>=6 and m<=12:
    sem=1

elif cur_year==1 and m>=1 and m<=6:
    sem=2

elif cur_year==1 and m>=6 and m<=12:
    sem=3

elif cur_year==2 and m>=1 and m<=6:
    sem=4

elif cur_year==2 and m>=6 and m<=12:
    sem=5

elif cur_year==3 and m>=1 and m<=6:
    sem=6

elif cur_year==3 and m>=6 and m<=12:
    sem=7

elif cur_year==4 and m>=1 and m<=6:
    sem=8

print(sem)

if int(code)>=001 and int(code)<=060:
    s='A'
    print(s)

else:
    s='B'
    print(s)

tempv1=b+"/"+str(sem)+"/"+s+"/"+day+"/"+"07:00:00"
subject_code=firebase.get('/Timetable/',tempv1)
print(subject_code)

tempv2=b+"/"+str(sem)+"/"+s+"/"+subject_code+"/"+year+"/"+str(m)+"/"+date
res=firebase.put('usn_date/',tempv2,usn1)
print(res)
