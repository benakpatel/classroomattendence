from firebase import firebase
firebase=firebase.FirebaseApplication('https://attendance-1c198.firebaseio.com/')
result = firebase.get('/card_details/c1',None)
print(result)
