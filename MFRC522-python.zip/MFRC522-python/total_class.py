from firebase import firebase
firebase=firebase.FirebaseApplication('https://studentattendancesystem-a6fbd.firebaseio.com/')
while 1:
    import time
    from datetime import datetime

    now=time.ctime()
    print(now)
    temp=now.split(' ')
    time=temp[3]
    day=temp[0]
    month=temp[1]
    date=temp[2]
    year=temp[4]
    print(temp)

    if month=="Jan":
        m=1
    elif month=="Feb":
        m=2
    elif month=="Mar":
        m=3
    elif month=="Apr":
        m=4
    elif month=="May":
        m=5
    elif month=="Jun":
        m=6
    elif month=="Jul":
        m=7
    elif month=="Aug":
        m=10
    elif month=="Nov":
        m=11
    elif month=="Dec":
        m=12


    if time=="14:21:00":
        print("hello")
        from firebase import firebase
        firebase=firebase.FirebaseApplication('https://studentattendancesystem-a6fbd.firebaseio.com/')
        branch="cs"

        if m>=1 and m<=6:
            sem=2
        else:
            sem=1

        branch="cs"
        #sem=2
        print(branch,sem)
        while sem<=8:
            temp2=branch+"/"+str(sem)+"/"+"A"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"A"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            temp2=branch+"/"+str(sem)+"/"+"B"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"B"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            (sem)=(sem)+2
        if m>=1 and m<=6:
            sem=2
        else:
            sem=1

        branch="cv"
        #sem=2
        print(branch,sem)
        while sem<=8:
            temp2=branch+"/"+str(sem)+"/"+"A"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"A"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            temp2=branch+"/"+str(sem)+"/"+"B"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"B"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            (sem)=(sem)+2

        if m>=1 and m<=6:
            sem=2
        else:
            sem=1

        branch="ec"
        #sem=2
        print(branch,sem)
        while sem<=8:
            temp2=branch+"/"+str(sem)+"/"+"A"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"A"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            temp2=branch+"/"+str(sem)+"/"+"B"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"B"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            (sem)=(sem)+2

        if m>=1 and m<=6:
            sem=2
        else:
            sem=1

        branch="ee"
        #sem=2
        print(branch,sem)
        while sem<=8:
            temp2=branch+"/"+str(sem)+"/"+"A"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"A"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            temp2=branch+"/"+str(sem)+"/"+"B"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"B"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            (sem)=(sem)+2

        if m>=1 and m<=6:
            sem=2
        else:
            sem=1

        branch="is"
        #sem=2
        print(branch,sem)
        while sem<=8:
            temp2=branch+"/"+str(sem)+"/"+"A"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"A"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            temp2=branch+"/"+str(sem)+"/"+"B"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"B"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            (sem)=(sem)+2

        if m>=1 and m<=6:
            sem=2
        else:
            sem=1

        branch="me"
        #sem=2
        print(branch,sem)
        while sem<=8:
            temp2=branch+"/"+str(sem)+"/"+"A"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"A"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            temp2=branch+"/"+str(sem)+"/"+"B"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"B"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            (sem)=(sem)+2

        if m>=1 and m<=6:
            sem=2
        else:
            sem=1

        branch="tc"
        #sem=2
        print(branch,sem)
        while sem<=8:
            temp2=branch+"/"+str(sem)+"/"+"A"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            #print(t[0],t[1],t[2],t[3],t[4])
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"A"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            temp2=branch+"/"+str(sem)+"/"+"B"+"/"+day
            tt=firebase.get('/Timetable/',temp2)
            t=tt.values()
            i=0
            while i<=5:
                temp1=branch+"/"+str(sem)+"/"+"B"+"/"+"total_class"+"/"+t[i]
                sub_val=firebase.get('/Timetable/',temp1)
                print(sub_val)
                (sub_val)=(sub_val)+1
                result=firebase.put('Timetable/',temp1,sub_val)
                print(result)
                i=i+1

            (sem)=(sem)+2

            #average_calculation
            usn_list=firebase.get('/StudentDetails/',None)
            usns=usn_list.keys()
            i=0
            while i<len(usns):
                usn1=usns[i]
                
                y=usn1[3:5]
                b=usn1[5:7]
                code=usn1[7:]
                print("y",y,b,code)

                cur_year=int(year)-2000-int(y)
                print(cur_year)

                if cur_year==0 and m>=6 and m<=12:
                    sem=1

                elif cur_year==1 and m>=1 and m<=6:
                    sem=2

                elif cur_year==1 and m>=6 and m<=12:
                    sem=3

                elif cur_year==2 and m>=1 and m<=6:
                    sem=4

                elif cur_year==2 and m>=6 and m<=12:
                    sem=5

                elif cur_year==3 and m>=1 and m<=6:
                    sem=6

                elif cur_year==3 and m>=6 and m<=12:
                    sem=7

                elif cur_year==4 and m>=1 and m<=6:
                    sem=8

                print(sem)

                if int(code)>=001 and int(code)<=060:
                    s='A'
                    print(s)

                else:
                    s='B'
                    print(s)

                tempv1=usn1+'/'+"Attendance"
                subject_codes=firebase.get('/StudentDetails/',tempv1)
                subject_codek=subject_codes.keys()
                subject_codev=subject_codes.values()
                print(subject_codek,subject_codev)
                j=0
                while j<len(subject_codek):
                    tempv2=b+'/'+str(sem)+'/'+s+'/'+"total_class"+'/'+subject_codek[j]
                    total_class=firebase.get('/Timetable/',tempv2)
                    print("tc",total_class)
                    avg=float(subject_codev[j])/float(total_class)*100
                    print(avg)
                    tempv3=usn1+'/'+"Average"+'/'+subject_codek[j]
                    res=firebase.put('/StudentDetails/',tempv3,avg)
                    j=j+1
                i=i+1
