#!/usr/bin/env python
# -*- coding: utf8 -*-
#####################LCD pgm###################
import time
import Adafruit_CharLCD as LCD
# Raspberry Pi pin setup BCM numbering
lcd_rs = 25  #changed to 27 from 25
lcd_en = 24
lcd_d4 = 23
lcd_d5 = 17
lcd_d6 = 18
lcd_d7 = 22
lcd_backlight = 2
# Define LCD column and row size for 16x2 LCD.
lcd_columns = 16
lcd_rows = 2
lcd = LCD.Adafruit_CharLCD(lcd_rs, lcd_en, lcd_d4, lcd_d5, lcd_d6, lcd_d7, lcd_columns, lcd_rows, lcd_backlight)
lcd.message('Hello\nworld!')
#####################################################



import RPi.GPIO as GPIO
import MFRC522
import signal
from datetime import datetime
from firebase import firebase
firebase=firebase.FirebaseApplication('https://studentattendancesystem-a6fbd.firebaseio.com/')
        

continue_reading = True

# Capture SIGINT for cleanup when the script is aborted
def end_read(signal,frame):
    global continue_reading
    print "Ctrl+C captured, ending read."
    continue_reading = False
    GPIO.cleanup()

# Hook the SIGINT
signal.signal(signal.SIGINT, end_read)

# Create an object of the class MFRC522
MIFAREReader = MFRC522.MFRC522()

# Welcome message
print "Welcome to the MFRC522 data read example"
print "Press Ctrl-C to stop."

# This loop keeps checking for chips. If one is near it will get the UID and authenticate
while continue_reading:
    
    # Scan for cards    
    (status,TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

    # If a card is found
    if status == MIFAREReader.MI_OK:
        print "Card detected"
    
    # Get the UID of the card
    (status,uid) = MIFAREReader.MFRC522_Anticoll()

    # If we have the UID, continue
    if status == MIFAREReader.MI_OK:

        card_no=str(uid[0])+str(uid[1])+str(uid[2])+str(uid[3])+str(uid[4])
        t=str(card_no)+'/'+str("usn")
        usn1=firebase.get('/StudentQueue/',t)
        print(usn1)
       
        # Print UID
        print "Card read UID: "+str(uid[0])+","+str(uid[1])+","+str(uid[2])+","+str(uid[3])+","+str(uid[4])

        from firebase import firebase
        firebase=firebase.FirebaseApplication('https://studentattendancesystem-a6fbd.firebaseio.com/')
        import time
        from datetime import datetime
        
        now=time.ctime()
        print(now)
        temp=now.split(' ')
        print(temp)
        day=temp[0]
        month=temp[1]
        date=temp[3]
        year=temp[5]
        time=temp[4]

        if month=="Jan":
            m=1
        elif month=="Feb":
            m=2
        elif month=="Mar":
            m=3
        elif month=="Apr":
            m=4
        elif month=="May":
            m=5
        elif month=="Jun":
            m=6
        elif month=="Jul":
            m=7
        elif month=="Aug":
            m=8
        elif month=="Sep":
            m=9
        elif month=="Oct":
            m=10
        elif month=="Nov":
            m=11
        elif month=="Dec":
            m=12


        y=usn1[3:5]
        b=usn1[5:7]
        code=usn1[7:]

        cur_year=int(year)-2000-int(y)
        print(cur_year)

        if cur_year==0 and m>=6 and m<=12:
            sem=1

        elif cur_year==1 and m>=1 and m<=6:
            sem=2

        elif cur_year==1 and m>=6 and m<=12:
            sem=3

        elif cur_year==2 and m>=1 and m<=6:
            sem=4

        elif cur_year==2 and m>=6 and m<=12:
            sem=5

        elif cur_year==3 and m>=1 and m<=6:
            sem=6

        elif cur_year==3 and m>=6 and m<=12:
            sem=7

        elif cur_year==4 and m>=1 and m<=6:
            sem=8

        print(sem)

        if int(code)>=001 and int(code)<=060:
            s='A'
            print(s)

        else:
            s='B'
            print(s)

        tempv1=b+"/"+str(sem)+"/"+s+"/"+day+"/"+"07:00:00"
        subject_code=firebase.get('/Timetable/',tempv1)
        print(subject_code)

        tempv2=b+"/"+str(sem)+"/"+s+"/"+subject_code+"/"+year+"/"+str(m)+"/"+date+"/"+usn1
        res=firebase.put('usn_date/',tempv2,"1")
        print(res)

        
        import time
        from datetime import datetime
        now=datetime.now()
        print(now)
        
        

        temp2=usn1+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+'status'
        #st=0
        #result2=firebase.put('student_details/',temp2,st)
        st=firebase.get('/Attendance',temp2,)
        if st<=0:
            st=1
            temp4=usn1+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+'status'
            result4=firebase.put('Attendance/',temp4,st)

            temp3=usn1+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+str(st)
            time3=str(now.hour)+':'+str(now.minute)+':'+str(now.second)
            result3=firebase.put('Attendance/',temp3,time3)
            print "entry_time:"
            
        else:
           if st%2!=0:
               st=st+1
               temp1=usn1+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+'status'
               result1=firebase.put('Attendance/',temp1,st)
               
               temp1=usn1+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+str(st)
               time1=str(now.hour)+':'+str(now.minute)+':'+str(now.second)
               result1=firebase.put('Attendance/',temp1,time1)
               #exit
               
               import time
               from datetime import datetime

               now=time.ctime()
               print(now)
               temp=now.split(' ')
               print(temp)
               day=temp[0]
               month=temp[1]
               date=temp[3]
               year=temp[5]
               time=temp[4]

               if month=="Jan":
                  m=1
               elif month=="Feb":
                  m=2
               elif month=="Mar":
                  m=3
               elif month=="Apr":
                  m=4
               elif month=="May":
                  m=5
               elif month=="Jun":
                  m=6
               elif month=="Jul":
                  m=7
               elif month=="Aug":
                  m=8
               elif month=="Sep":
                  m=9
               elif month=="Oct":
                  m=10
               elif month=="Nov":
                  m=11
               elif month=="Dec":
                  m=12


               y=usn1[3:5]
               b=usn1[5:7]
               code=usn1[7:]
               print(code)

               cur_year=int(year)-2000-int(y)
               print(cur_year)

               if cur_year==0 and m>=6 and m<=12:
                  sem=1

               elif cur_year==1 and m>=1 and m<=6:
                  sem=2

               elif cur_year==1 and m>=6 and m<=12:
                  sem=3

               elif cur_year==2 and m>=1 and m<=6:
                  sem=4

               elif cur_year==2 and m>=6 and m<=12:
                  sem=5

               elif cur_year==3 and m>=1 and m<=6:
                  sem=6

               elif cur_year==3 and m>=6 and m<=12:
                  sem=7

               elif cur_year==4 and m>=1 and m<=6:
                  sem=8

               print(sem)

               if int(code)>=001 and int(code)<=060:
                    s='A'
                    print(s)

               else:
                    s='B'
                    print(s)
                    
               print(usn1,year,m,date)
               temp2=usn1+'/'+str(year)+'/'+str(m)+'/'+str(date)+'/'+'status'
               status=firebase.get('/Attendance/',temp2)

               if int(status)%2==0:
                    status=status-1
                    temp3=usn1+'/'+str(year)+'/'+str(m)+'/'+str(date)+'/'+str(status)
                    entry_time=firebase.get('/Attendance/',temp3)
                    print(entry_time)

               from datetime import datetime
               FMT = '%H:%M:%S'
               diff = datetime.strptime(time, FMT) - datetime.strptime(entry_time, FMT)
               print(diff)
               str_time= str(diff)
               hr=str_time[0:1]
               print(hr)


               i=0
               while i<int(hr):
    
                    temp4=b+'/'+str(sem)+'/'+s+'/'+day+'/'+str(entry_time)
                    tt=firebase.get('/Timetable/',temp4)
                    print(tt)

                    temp4=usn1+'/'+"Attendance"+'/'+tt
                    sub_code=firebase.get('/StudentDetails/',temp4)
                    if sub_code==None:
                        sub_code=firebase.put('/StudentDetails/',temp4,0)
                    (sub_code)=(sub_code)+1

                    result=firebase.put('StudentDetails/',temp4,sub_code)
                    print(result)

                    import datetime
                    FMT = '%H:%M:%S'
                    etime = datetime.datetime.strptime(entry_time, FMT) +  datetime.timedelta(hours=1)
                    et=str(etime)
                    print("et:",et)
                    entry_time=et[11:]
    
                    print(entry_time)
                    i=i+1

           else:
               st=st+1
               temp3=usn1+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+'status'
               result3=firebase.put('Attendance/',temp3,st)
               
               temp3=usn1+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+str(st)
               time3=str(now.hour)+':'+str(now.minute)+':'+str(now.second)
               result3=firebase.put('Attendance/',temp3,time3)
               print "entry_time:"
            
               

        

         # This is the default key for authentication
        key = [0xFF,0xFF,0xFF,0xFF,0xFF,0xFF]
        
        # Select the scanned tag
        MIFAREReader.MFRC522_SelectTag(uid)

        # Authenticate
        status = MIFAREReader.MFRC522_Auth(MIFAREReader.PICC_AUTHENT1A, 8, key, uid)

        # Check if authenticated
        if status == MIFAREReader.MI_OK:
            MIFAREReader.MFRC522_Read(8)
            MIFAREReader.MFRC522_StopCrypto1()
        else:
            print "Authentication error"



            
          
      


       
