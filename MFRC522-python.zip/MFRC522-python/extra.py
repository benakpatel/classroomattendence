if st%2!=0:
            temp1=usn+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+'exit_time'
            time=str(now.hour)+':'+str(now.minute)+':'+str(now.second)
            result1=firebase.put('student_details/',temp1,time)
            print "exit_time:"
            st=st+1
            temp3=usn+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+'status'
            result3=firebase.put('student_details/',temp2,st)
          
        else:
            
            st=st+1
            result2=firebase.put('student_details/',temp2,st)
            temp3=usn+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+'entry_time'
            time3=str(now.hour)+':'+str(now.minute)+':'+str(now.second)
            result3=firebase.put('student_details/',temp3,time3)
            print "entry_time:"
           # st=st+1
        temp3=usn+'/'+str(now.year)+'/'+str(now.month)+'/'+str(now.day)+'/'+'status'
            #result3=firebase.put('student_details/',temp2,st)
            

        print "year:",now.year
        print "month:",now.month
        print "day:",now.day

        print "hour:",now.hour
        print "minute:",now.minute
        print "second:",now.second
